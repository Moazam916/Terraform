import boto3
def lambda_handler(event, context):
    print(event)
    return 'Hello from Lambda!'